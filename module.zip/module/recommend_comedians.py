import json

# Load comedians data from JSON file
def load_comedians(file_path="comedians.json"):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return []
    except json.JSONDecodeError:
        print(f"Error: The file '{file_path}' contains invalid JSON.")
        return []

# Recommendation function based on filters
def recommend_comedians(genre=None, language=None, min_experience=None, min_rating=None, origin=None):
    comedians = load_comedians()

    if not comedians:
        return []  # Return empty list if no data is found

    filtered_comedians = []

    for comedian in comedians:
        if genre:
            genres = [g.strip().lower() for g in genre.split(",")]
            if not any(g in map(str.lower, comedian["genre"]) for g in genres):
                continue

        if language:
            languages = [l.strip().lower() for l in language.split(",")]
            if not any(l in map(str.lower, comedian["language"]) for l in languages):
                continue

        if min_experience and comedian.get("experience", 0) < min_experience:
            continue
        
        if min_rating and comedian.get("rating", 0) < min_rating:
            continue
        
        if origin and origin.lower() != comedian["origin"].lower():
            continue
        
        filtered_comedians.append(comedian)

    return filtered_comedians

# Example usage
if __name__ == "__main__":
    print("\n🎭 Welcome to the Comedian Recommendation System 🎭\n")

    user_genre = input("Enter preferred genre (comma-separated, e.g., Stand-up, Satire, Music Comedy): ").strip()
    user_language = input("Enter preferred language (comma-separated, e.g., English, Hindi, French): ").strip()
    user_experience = input("Enter minimum years of experience (or leave blank): ").strip()
    user_rating = input("Enter minimum rating (or leave blank): ").strip()
    user_origin = input("Enter country of origin (or leave blank): ").strip()

    # Convert inputs to the correct type
    user_experience = int(user_experience) if user_experience.isdigit() else None
    user_rating = float(user_rating) if user_rating.replace('.', '', 1).isdigit() else None

    recommendations = recommend_comedians(
        genre=user_genre if user_genre else None,
        language=user_language if user_language else None,
        min_experience=user_experience,
        min_rating=user_rating,
        origin=user_origin if user_origin else None
    )

    print("\n🎤 Recommended Comedians:")
    if recommendations:
        for comedian in recommendations:
            print(f"✅ {comedian['name']} - {comedian['genre']} ({comedian['language']}) | {comedian['experience']} years | Rating: {comedian['rating']} | Country: {comedian['origin']}")
    else:
        print("❌ No comedians match your criteria.")
