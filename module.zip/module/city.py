import json

# Load comedians data from JSON file
def load_comedians(file_path="indian_comedians.json"):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return []
    except json.JSONDecodeError:
        print(f"Error: The file '{file_path}' contains invalid JSON.")
        return []

# Recommendation function based on filters
def city(city=None, ticket_price=None, popularity=None, genre=None, language=None):
    comedians = load_comedians()
    
    if not comedians:
        return []

    filtered_comedians = []

    for comedian in comedians:
        if city:
            cities = [c.strip().lower() for c in city.split(",")]
            if not any(c in map(str.lower, comedian["city"]) for c in cities):
                continue

        if ticket_price and ticket_price.lower() != comedian["ticket_price"].lower():
            continue
        
        if popularity and popularity.lower() != comedian["popularity"].lower():
            continue

        if genre:
            genres = [g.strip().lower() for g in genre.split(",")]
            if not any(g in map(str.lower, comedian["genre"]) for g in genres):
                continue

        if language:
            languages = [l.strip().lower() for l in language.split(",")]
            if not any(l in map(str.lower, comedian["language"]) for l in languages):
                continue
        
        filtered_comedians.append(comedian)

    return filtered_comedians

# Example usage
if __name__ == "__main__":
    print("\n🎭 Welcome to the City-Based Comedian Recommendation System 🎭\n")

    user_city = input("Enter city (comma-separated, e.g., Mumbai, Delhi, Bangalore): ").strip()
    user_ticket_price = input("Enter ticket price range (Affordable, Standard, Premium): ").strip()
    user_popularity = input("Enter popularity level (Emerging, Trending, Legendary): ").strip()
    user_genre = input("Enter preferred genre (comma-separated, e.g., Stand-up, Observational, Satire): ").strip()
    user_language = input("Enter preferred language (comma-separated, e.g., English, Hindi, Tamil): ").strip()

    recommendations = city(
        city=user_city if user_city else None,
        ticket_price=user_ticket_price if user_ticket_price else None,
        popularity=user_popularity if user_popularity else None,
        genre=user_genre if user_genre else None,
        language=user_language if user_language else None
    )

    print("\n🎤 Recommended Comedians:")
    if recommendations:
        for comedian in recommendations:
            print(f"✅ {comedian['name']} - {comedian['genre']} ({comedian['language']}) | Performing in: {', '.join(comedian['city'])} | Ticket: {comedian['ticket_price']} | Rating: {comedian['rating']} | Popularity: {comedian['popularity']}")
    else:
        print("❌ No comedians match your criteria.")
