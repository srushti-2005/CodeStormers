from flask import Flask, render_template, request, jsonify
import json

app = Flask(__name__)

# Load comedians data from JSON file
def load_comedians(file_path="comedians.json"):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return []
    except json.JSONDecodeError:
        print(f"Error: The file '{file_path}' contains invalid JSON.")
        return []

# Recommendation function based on filters
def recommend_comedians(genre=None, language=None, min_experience=None, min_rating=None, origin=None):
    comedians = load_comedians()

    if not comedians:
        return []  # Return empty list if no data is found

    filtered_comedians = []

    for comedian in comedians:
        if genre:
            genres = [g.strip().lower() for g in genre.split(",")]
            if not any(g in map(str.lower, comedian["genre"]) for g in genres):
                continue

        if language:
            languages = [l.strip().lower() for l in language.split(",")]
            if not any(l in map(str.lower, comedian["language"]) for l in languages):
                continue

        if min_experience and comedian.get("experience", 0) < min_experience:
            continue
        
        if min_rating and comedian.get("rating", 0) < min_rating:
            continue
        
        if origin and origin.lower() != comedian["origin"].lower():
            continue
        
        filtered_comedians.append(comedian)

    return filtered_comedians

# Route to serve the HTML frontend
@app.route("/")
def home():
    return render_template("audiencepage.html")

# Route to handle recommendations
@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.json  # Get user preferences from the frontend
    recommendations = recommend_comedians(
        genre=data.get("genre"),
        language=data.get("language"),
        min_experience=data.get("min_experience"),
        min_rating=data.get("min_rating"),
        origin=data.get("origin")
    )
    return jsonify(recommendations)

if __name__ == "__main__":
    app.run(debug=True)