[
    {
        "id": 1,
        "name": "Vir Das",
        "email": "vir.das@email.com",
        "verified_status": true,
        "experience": 15,
        "past_no_shows": 0
    },
    {
        "id": 2,
        "name": "Zakir Khan",
        "email": "zakir.khan@email.com",
        "verified_status": true,
        "experience": 12,
        "past_no_shows": 1
    },
    {
        "id": 3,
        "name": "Kenny Sebastian",
        "email": "kenny.sebastian@email.com",
        "verified_status": true,
        "experience": 10,
        "past_no_shows": 2
    },
    {
        "id": 4,
        "name": "Atul Khatri",
        "email": "atul.khatri@email.com",
        "verified_status": true,
        "experience": 20,
        "past_no_shows": 0
    },
    {
        "id": 5,
        "name": "Abhishek Upmanyu",
        "email": "abhishek.upmanyu@email.com",
        "verified_status": true,
        "experience": 8,
        "past_no_shows": 3
    
    {
        "id": 6,
        "name": "Fake Artist 1",
        "email": "fake.artist1@email.com",
        "verified_status": false,
        "experience": 1,
        "past_no_shows": 5
    },
    {
        "id": 7,
        "name": "Fake Artist 2",
        "email": "fake.artist2@email.com",
        "verified_status": false,
        "experience": 2,
        "past_no_shows": 4
    }
]
