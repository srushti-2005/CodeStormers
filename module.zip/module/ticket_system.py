import json

# Load data from JSON files
def load_data(file_path):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        return []

# Save data back to JSON files
def save_data(file_path, data):
    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4)

# Get user data
def get_user(email):
    users = load_data("users.json")
    return next((u for u in users if u["email"] == email), None)

# Get event data
def get_event(event_id):
    events = load_data("events.json")
    return next((e for e in events if e["id"] == event_id), None)

# Ticket purchase function
def buy_ticket(email, event_id, quantity):
    users = load_data("users.json")
    events = load_data("events.json")

    user = get_user(email)
    event = get_event(event_id)

    if not user:
        print("❌ User not found.")
        return
    
    if not event:
        print("❌ Event not found.")
        return

    if not user["verified"]:
        print("❌ Unverified users cannot buy tickets.")
        return

    if quantity > event["max_tickets_per_user"]:
        print(f"❌ Max {event['max_tickets_per_user']} tickets allowed per user.")
        return

    if event["tickets_sold"] + quantity > event["total_tickets"]:
        print("❌ Not enough tickets left.")
        return

    # Update event sales
    event["tickets_sold"] += quantity

    # Update user purchase history
    user["tickets_bought"].append({"event_id": event_id, "quantity": quantity})

    save_data("users.json", users)
    save_data("events.json", events)

    print(f"✅ {quantity} tickets booked successfully for {event['name']}!")

# Main interaction
if __name__ == "__main__":
    print("\n🎭 Welcome to Secure Ticket Booking 🎭")
    email = input("Enter your email: ").strip()
    event_id = int(input("Enter Event ID: ").strip())
    quantity = int(input("Enter number of tickets: ").strip())

    buy_ticket(email, event_id, quantity)
