from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample comedian data
comedians = [
    {"name": "Vir Das", "genre": ["Stand-up"], "language": ["English", "Hindi"], "experience": 10, "rating": 4.7, "origin": "India"},
    {"name": "Trevor Noah", "genre": ["Satire", "Stand-up"], "language": ["English"], "experience": 12, "rating": 4.9, "origin": "South Africa"},
    {"name": "Zakir Khan", "genre": ["Stand-up"], "language": ["Hindi"], "experience": 8, "rating": 4.8, "origin": "India"},
    {"name": "Hasan Minhaj", "genre": ["Satire", "Storytelling"], "language": ["English"], "experience": 15, "rating": 4.6, "origin": "USA"},
]

@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.json
    genre = data.get("genre", "").lower()
    language = data.get("language", "").lower()
    min_experience = int(data.get("min_experience", 0))
    min_rating = float(data.get("min_rating", 0))
    origin = data.get("origin", "").lower()

    # Filter comedians based on user input
    filtered_comedians = [
        comedian for comedian in comedians
        if (not genre or any(g.lower() in genre for g in comedian["genre"]))
        and (not language or any(l.lower() in language for l in comedian["language"]))
        and comedian["experience"] >= min_experience
        and comedian["rating"] >= min_rating
        and (not origin or comedian["origin"].lower() == origin)
    ]

    return jsonify(filtered_comedians)

if __name__ == "__main__":
    app.run(debug=True)
