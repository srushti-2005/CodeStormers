import json
import random
import time

# Load artist data from JSON file
def load_artists(file_path="artists.json"):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return []
    except json.JSONDecodeError:
        print(f"Error: The file '{file_path}' contains invalid JSON.")
        return []

# Simulate sending OTP (for verification step)
def send_otp():
    otp = random.randint(1000, 9999)
    print(f"\n🔹 OTP sent: {otp}")  # Simulating sending OTP
    return otp

# Function to verify artist and allow booking
def book_venue(artist_email):
    artists = load_artists()
    
    # Find artist by email
    artist = next((a for a in artists if a["email"] == artist_email), None)
    
    if not artist:
        print("❌ Artist not found.")
        return
    
    # Check if artist is verified
    if not artist["verified_status"]:
        print("❌ Booking denied. Artist is not verified.")
        return
    
    # Check if artist has too many no-shows
    if artist["past_no_shows"] >= 3:
        print("⚠️ Booking denied. Artist is temporarily banned due to repeated no-shows.")
        return
    
    # OTP verification
    correct_otp = send_otp()
    user_otp = input("Enter the OTP received: ").strip()
    
    if user_otp != str(correct_otp):
        print("❌ OTP verification failed. Booking denied.")
        return
    
    print(f"\n✅ Booking successful! Artist {artist['name']} is scheduled.")
    
    # Simulating updating the database (in real implementation, we'd update the JSON file)
    print("📌 Note: Any future no-shows will be recorded.")

# Example usage
if __name__ == "__main__":
    print("\n🎭 Welcome to the Artist Booking System 🎭")
    artist_email = input("Enter artist email to book a venue: ").strip()
    book_venue(artist_email)
