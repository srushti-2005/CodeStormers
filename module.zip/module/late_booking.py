import json
from datetime import datetime, timedelta

# Load bookings data from JSON
def load_bookings(file_path="event_bookings.json"):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
        return []
    except json.JSONDecodeError:
        print(f"Error: The file '{file_path}' contains invalid JSON.")
        return []

# Save updated bookings to JSON
def save_bookings(bookings, file_path="event_bookings.json"):
    try:
        with open(file_path, "w", encoding="utf-8") as file:
            json.dump(bookings, file, indent=4)
    except Exception as e:
        print(f"Error saving bookings: {e}")

# Function to check last-minute cancellations
def check_last_minute_cancellations(bookings):
    last_minute_penalty = []
    today = datetime.today()

    for booking in bookings:
        if booking["status"] == "Cancelled":
            event_date = datetime.strptime(booking["event_date"], "%Y-%m-%d")
            cancellation_date = datetime.strptime(booking["cancellation_date"], "%Y-%m-%d")
            days_before_event = (event_date - cancellation_date).days

            if 0 <= days_before_event <= 2:  # Last-minute cancellations (0-2 days before event)
                penalty_fee = 500  # Penalty fee for last-minute cancellations
                last_minute_penalty.append({
                    "user_name": booking["user_name"],
                    "event": booking["event"],
                    "venue": booking["venue"],
                    "cancellation_date": booking["cancellation_date"],
                    "penalty_fee": penalty_fee
                })
    
    return last_minute_penalty

# Function to cancel a booking
def cancel_booking(bookings, user_name, event_name):
    today = datetime.today().strftime("%Y-%m-%d")

    for booking in bookings:
        if booking["user_name"].lower() == user_name.lower() and booking["event"].lower() == event_name.lower():
            if booking["status"] == "Cancelled":
                print("⚠️ Booking already cancelled.")
                return
            
            event_date = datetime.strptime(booking["event_date"], "%Y-%m-%d")
            days_before_event = (event_date - datetime.today()).days

            if 0 <= days_before_event <= 2:
                print("❌ Last-minute cancellation detected! A penalty fee of ₹500 will be charged.")
            else:
                print("✅ Booking cancelled successfully.")

            booking["status"] = "Cancelled"
            booking["cancellation_date"] = today
            save_bookings(bookings)
            return
    
    print("⚠️ No matching booking found.")

# Main Program
if __name__ == "__main__":
    bookings = load_bookings()

    print("\n🎭 Welcome to the No Last-Minute Cancellation System 🎭")
    print("1️⃣ Check last-minute cancellations & penalties")
    print("2️⃣ Cancel a booking")
    choice = input("Enter your choice (1/2): ").strip()

    if choice == "1":
        penalties = check_last_minute_cancellations(bookings)
        if penalties:
            print("\n🚨 Last-Minute Cancellations & Penalties 🚨")
            for penalty in penalties:
                print(f"User: {penalty['user_name']} | Event: {penalty['event']} | Venue: {penalty['venue']} | Penalty: ₹{penalty['penalty_fee']}")
        else:
            print("✅ No last-minute cancellations detected.")

    elif choice == "2":
        user_name = input("Enter your name: ").strip()
        event_name = input("Enter the event name: ").strip()
        cancel_booking(bookings, user_name, event_name)

    else:
        print("⚠️ Invalid choice. Please try again.")
